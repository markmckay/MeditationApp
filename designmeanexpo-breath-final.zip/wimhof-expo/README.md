Wim Hof-style breathing app with inhale/exhale audio, ambient loop, settings, and history.
